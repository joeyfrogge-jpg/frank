"""FrankGPT model package."""
